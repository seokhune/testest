#!/usr/bin/env python3
"""원고 PDF를 년 단위로 분할한다 (로컬, 워크플로우 아님).
출력: out/<년도>_<페이지범위>.pdf 파일들 + segments.json (검수 워크플로우 실행용)

사용:
  python3 split_years.py --input <원고 PDF> --outdir out
  python3 split_years.py --input <원고 PDF> --outdir out --min-pages 3   # 3p 미만 년도는 앞 년도에 합침
"""
from __future__ import annotations
import argparse, json, re, sys, unicodedata
from pathlib import Path

from pypdf import PdfReader, PdfWriter

YEAR_RE = re.compile(
    r'^\s*(?:([갑을병정무기경신임계][자축인묘진사오미신유술해]){1,2}'
    r'|([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]){1,2})'
    r'\s*(고려\s*)?(태조|혜종|정종|광종|경종|성종|목종|현종|덕종|문종)'
    r'\s*(\d+년|원년)')


def find_year_pages(reader: PdfReader):
    """각 페이지의 첫 유효 줄들을 훑어 년도 헤더가 있는 페이지를 찾는다.
    반환: [(1-based 페이지, 년도라벨)] — 페이지당 최대 1개"""
    hits = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        for ln in text.splitlines():
            ln = ln.strip()
            if not ln:
                continue
            m = YEAR_RE.match(unicodedata.normalize('NFC', ln))
            if m:
                ganji = m.group(1) or m.group(2)
                hits.append((i + 1, f"{ganji} {m.group(4)} {m.group(5)}"))
                break   # 페이지당 첫 번째 헤더만
    return hits


def build_segments(total: int, hits: list, min_pages: int):
    """년도 헤더 위치 → 세그먼트 목록.
    첫 헤더 앞 페이지는 '서두' 세그먼트로, 마지막 년도는 문서 끝까지."""
    segs = []
    if not hits:
        return [{"label": "전체", "page_start": 1, "page_end": total, "year": None}]
    first_page = hits[0][0]
    if first_page > 1:
        segs.append({"label": f"서두_p1-{first_page-1}", "page_start": 1,
                     "page_end": first_page - 1, "year": None})
    for k, (pg, year) in enumerate(hits):
        end = hits[k + 1][0] - 1 if k + 1 < len(hits) else total
        segs.append({"label": year, "page_start": pg, "page_end": end, "year": year})
    # 너무 작은 세그먼트는 앞 세그먼트에 병합
    if min_pages and min_pages > 1:
        merged = []
        for s in segs:
            if merged and s["page_end"] - s["page_start"] + 1 < min_pages \
                    and merged[-1].get("year") is not None:
                merged[-1]["page_end"] = s["page_end"]
                merged[-1]["label"] = f"{merged[-1]['label']}+{s['label']}"
            else:
                merged.append(dict(s))
        segs = merged
    for s in segs:
        s["pages"] = s["page_end"] - s["page_start"] + 1
    return segs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--outdir', default='out')
    ap.add_argument('--min-pages', type=int, default=0,
                    help='이 값보다 작은 년도 세그먼트는 앞 년도에 합친다 (0=순수 년 단위)')
    a = ap.parse_args()

    src = Path(a.input)
    if not src.exists():
        sys.exit(f"입력 파일 없음: {src}")
    reader = PdfReader(str(src))
    total = len(reader.pages)
    hits = find_year_pages(reader)
    print(f"[입력] {src.name}  {total}페이지")
    print(f"[탐지] 년도 헤더 {len(hits)}개: " + ", ".join(f"{y}(p{p})" for p, y in hits[:8])
          + (" ..." if len(hits) > 8 else ""))

    segs = build_segments(total, hits, a.min_pages)
    outdir = Path(a.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    manifest = {"source": src.name, "total_pages": total,
                "workflow": "pdf-document-review", "segments": []}
    for s in segs:
        w = PdfWriter()
        for i in range(s["page_start"] - 1, s["page_end"]):
            w.add_page(reader.pages[i])
        fname = f"{s['label']}_p{s['page_start']}-{s['page_end']}.pdf"
        out = outdir / fname
        with open(out, 'wb') as f:
            w.write(f)
        entry = {"label": s["label"], "file": fname,
                 "page_start": s["page_start"], "page_end": s["page_end"],
                 "pages": s["pages"],
                 "workflow_args": {"file_name": fname,
                                   "page_start": 1, "page_end": s["pages"]}}
        manifest["segments"].append(entry)
        print(f"[분할] {fname}  {s['pages']}p")

    mpath = outdir / 'segments.json'
    mpath.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f"[완료] 세그먼트 {len(segs)}개 → {outdir}/ , 실행 명세 {mpath}")


if __name__ == '__main__':
    main()
