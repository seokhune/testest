#!/usr/bin/env python3
"""조선사 최종본 빌드: 원본틀(원고 레이아웃)에 ① 교정 현위치 반영 ② 년도 경계 리포트 삽입 ③ 전권 병합.
출력은 로컬 파일. 드라이브 업로드는 하지 않는다.

사용:
  python3 build_final.py build --frame-dir <원본틀 DOCX 폴더> --report <report.txt> --outdir <출력 폴더>
  python3 build_final.py split --frame-dir <폴더> --outdir <폴더> [--max-bytes N]
  python3 build_final.py verify --outdir <폴더>
"""
from __future__ import annotations
import argparse, re, sys, unicodedata
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph
from docxcompose.composer import Composer

# ---------- 패턴 ----------
# 년도 헤더: 제3편(태조~문종) 기준. 제2편(신라 왕호)은 아래 주석의 패턴으로 교체.
#   제2편용: r'^\s*(?:([갑을병정무기경신임계][자축인묘진사오미신유술해]){1,2}|([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]){1,2})\s*(신라|고려)?\s*(\S{2,4}왕)\s*(\d+년|원년)'
GAN_H = '[갑을병정무기경신임계]'
JI_H = '[자축인묘진사오미신유술해]'
GAN = '[甲乙丙丁戊己庚辛壬癸]'
JI = '[子丑寅卯辰巳午未申酉戌亥]'
YEAR_RE = re.compile(
    r'^\s*(?:(' + GAN_H + JI_H + r')|(' + GAN + JI + r'))'
    r'{1,2}\s*(고려\s*)?(태조|혜종|정종|광종)\s*(\d+년|원년)')
REPORT_RE = re.compile(r'〔\s*(.+?)\s*검수\s*리포트\s*〕')
ORIG_RE = re.compile(r'^\s*[—–-]\s*원문\s*[:：]\s*(.+)$')
FIX_RE = re.compile(r'^\s*[—–-]\s*수정\s*[:：]\s*(.+)$')
MD_RE = re.compile(r'(\*\*.+?\*\*)')


def norm(s: str) -> str:
    """비교용 정규화: NFC, 공백 제거, 괄호 통일, …/... 제거, 마크다운·역자주 제거"""
    s = unicodedata.normalize('NFC', s)
    s = s.replace('（', '(').replace('）', ')')
    s = re.sub(r'\s+', '', s)
    s = s.replace('…', '').replace('...', '')
    s = s.replace('**', '')
    s = re.sub(r'<역자\s*주>', '', s)
    return s


def strip_md(s: str) -> str:
    return s.replace('**', '')


# ---------- 리포트 파싱 ----------
def parse_report(text: str):
    """리포트 텍스트 → (교정목록 [(원문,수정)], {년도헤더: [문단텍스트]})
    교정 쌍(—원문/—수정)은 본문 반영에도 쓰고, 삽입 리포트에도 그대로 남긴다."""
    corrections, year_sections = [], {}
    cur_header, pending_orig = None, None
    for ln in text.splitlines():
        m = ORIG_RE.match(ln)
        if m:
            pending_orig = m.group(1).strip()
            if cur_header is not None:
                year_sections[cur_header].append(ln.rstrip())
            continue
        m = FIX_RE.match(ln)
        if m and pending_orig is not None:
            corrections.append((pending_orig, m.group(1).strip()))
            pending_orig = None
            if cur_header is not None:
                year_sections[cur_header].append(ln.rstrip())
            continue
        m = REPORT_RE.search(ln)
        if m:
            cur_header = m.group(1).strip()
            year_sections.setdefault(cur_header, [])
            continue
        if cur_header is not None and ln.strip():
            year_sections[cur_header].append(ln.rstrip())
    return corrections, year_sections


# ---------- ① 교정 현위치 반영 ----------
def _rebuild(text: str, orig: str, fixed: str) -> str:
    """원문 조각(…·마크다운 포함)을 찾아 수정문으로 교체한 문단 텍스트 반환"""
    o = norm(orig)
    mapping, nn = [], []
    for i, ch in enumerate(text):
        if ch in ' \t…':
            continue
        mapping.append(i)
        nn.append(unicodedata.normalize('NFC', ch).replace('（', '(').replace('）', ')').replace('**', ''))
    n = ''.join(nn)
    j = n.find(o)
    if j < 0:
        return text
    start = mapping[j]
    end = mapping[j + len(o) - 1] + 1 if j + len(o) - 1 < len(mapping) else len(text)
    return text[:start] + strip_md(fixed) + text[end:]


def _trim_ellipsis(s: str) -> str:
    """발췌 마커(앞뒤 …/...) 제거 — 변경 핵심 부분만 남긴다"""
    return re.sub(r'^[\.\s…]+|[\.\s…]+$', '', s)


def apply_correction(doc: Document, orig: str, fixed: str) -> bool:
    # 발췌 마커(…)를 떼고 핵심 부분끼리 비교·교체한다
    orig_core = _trim_ellipsis(strip_md(orig))
    fixed_core = _trim_ellipsis(strip_md(fixed))
    o = norm(orig_core)
    if not o or o == norm(fixed_core):
        return False
    for p in doc.paragraphs:
        if o not in norm(p.text):
            continue
        if orig_core in p.text:
            new_text = p.text.replace(orig_core, fixed_core, 1)
        else:
            new_text = _rebuild(p.text, orig_core, fixed_core)
        if new_text == p.text:
            continue
        fmt = p.runs[0] if p.runs else None
        for r in list(p.runs):
            r._element.getparent().remove(r._element)
        run = p.add_run(new_text)
        if fmt is not None:
            run.bold = fmt.bold
            run.font.size = fmt.font.size
            src_rpr = fmt._element.rPr
            if src_rpr is not None and src_rpr.rFonts is not None:
                rpr = run._element.get_or_add_rPr()
                rf = OxmlElement('w:rFonts')
                for a in ('ascii', 'hAnsi', 'eastAsia'):
                    v = src_rpr.rFonts.get(qn('w:' + a))
                    if v:
                        rf.set(qn('w:' + a), v)
                rpr.append(rf)
        return True
    return False


# ---------- ② 년도 경계 리포트 삽입 ----------
def _mk_para_after(prev_el, parent_obj, text: str):
    """prev_el 뒤에 새 문단 삽입"""
    p_el = OxmlElement('w:p')
    prev_el.addnext(p_el)
    para = Paragraph(p_el, parent_obj)
    for part in MD_RE.split(text):
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            r = para.add_run(part[2:-2])
            r.bold = True
        else:
            para.add_run(part)
    return p_el


def _mk_para_before(anchor_el, parent_obj, prev_el, text: str):
    p_el = OxmlElement('w:p')
    if prev_el is not None:
        prev_el.addnext(p_el)
    else:
        anchor_el.addprevious(p_el)
    para = Paragraph(p_el, parent_obj)
    for part in MD_RE.split(text):
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            r = para.add_run(part[2:-2])
            r.bold = True
        else:
            para.add_run(part)
    return p_el


def _year_key(header: str):
    m = YEAR_RE.search(header)
    if not m:
        return None
    ganji = m.group(1) or m.group(2)   # 한글 간지(그룹1) 또는 한문 간지(그룹2)
    return (ganji, m.group(4), m.group(5))


def insert_year_reports(doc: Document, year_sections: dict) -> int:
    """각 년도 리포트를 해당 년도 내용 뒤(= 다음 년도 헤더 직전)에 삽입.
    마지막 년도는 문서 끝에 삽입."""
    if not year_sections:
        return 0
    heads = [(p, _year_key(p.text)) for p in doc.paragraphs if YEAR_RE.match(p.text)]
    if not heads:
        return 0
    used, inserted = set(), 0
    body = doc.paragraphs[0]._parent
    for k, (p, key) in enumerate(heads):
        if key is None:
            continue
        for header, texts in year_sections.items():
            if header in used:
                continue
            hk = _year_key(header)
            if hk is None or hk[:2] != key[:2]:
                continue
            if not (hk[2] == key[2] or hk[2] in key[2] or key[2] in hk[2]):
                continue
            payload = ['〔' + header + ' 검수 리포트〕'] + texts
            if k + 1 < len(heads):
                anchor = heads[k + 1][0]._p
                prev = None
                for t in payload:
                    prev = _mk_para_before(anchor, body, prev, t)
            else:
                # 마지막 년도: 그 년도 본문 전부 뒤(문서 끝)에 삽입
                prev = doc.paragraphs[-1]._p
                for t in payload:
                    prev = _mk_para_after(prev, body, t)
            used.add(header)
            inserted += 1
            break
    return inserted


# ---------- ③ 병합 / 분할 ----------
def merge_frames(frame_paths, out: Path) -> Path:
    master = Document(str(frame_paths[0]))
    composer = Composer(master)
    for p in frame_paths[1:]:
        composer.append(Document(str(p)))
    out.parent.mkdir(parents=True, exist_ok=True)
    composer.save(str(out))
    return out


def split_frames(frame_paths, outdir: Path, max_bytes: int):
    """프레임 단위 병합본을 max_bytes 이하 조각으로 나눠 저장"""
    outdir.mkdir(parents=True, exist_ok=True)
    chunks, cur, cur_size = [], [], 0
    for p in frame_paths:
        sz = Path(p).stat().st_size
        if cur and cur_size + sz > max_bytes:
            chunks.append(cur)
            cur, cur_size = [], 0
        cur.append(p)
        cur_size += sz
    if cur:
        chunks.append(cur)
    outs = []
    n = len(chunks)
    for i, grp in enumerate(chunks, 1):
        name = f"조선사_최종본_교정반영_리포트포함_{i}of{n}.docx"
        out = merge_frames(grp, outdir / name)
        print(f"[split] {name}  {out.stat().st_size:,} bytes  (원본틀 {len(grp)}개)")
        outs.append(out)
    return outs


# ---------- 메인 ----------
def build(frame_dir: Path, report_path: Path, outdir: Path, max_bytes: int):
    frames = sorted(frame_dir.glob('*.docx'), key=lambda p: p.name)
    if not frames:
        sys.exit(f"원본틀 없음: {frame_dir}")
    print(f"[frames] {len(frames)}개 원본틀")
    report_text = report_path.read_text(encoding='utf-8')
    corrections, year_sections = parse_report(report_text)
    print(f"[report] 교정 {len(corrections)}건, 년도 리포트 {len(year_sections)}개 섹션")

    # 전권 병합 후 교정·리포트 삽입(년도 헤더가 구간 경계에 걸칠 수 있으므로)
    merged_tmp = outdir / '_merged_tmp.docx'
    merge_frames(frames, merged_tmp)
    doc = Document(str(merged_tmp))

    ok = fail = 0
    for orig, fixed in corrections:
        if apply_correction(doc, orig, fixed):
            ok += 1
        else:
            fail += 1
            print(f"  [교정미적용] 원문: {orig[:60]}")
    print(f"[교정] 적용 {ok} / 미적용 {fail}")

    n = insert_year_reports(doc, year_sections)
    print(f"[리포트] 년도 경계 삽입 {n}개 섹션")
    doc.save(str(merged_tmp))

    size = merged_tmp.stat().st_size
    if size <= max_bytes:
        final = outdir / "최종본_교정반영_리포트포함.docx"
        merged_tmp.rename(final)
        print(f"[done] {final}  {final.stat().st_size:,} bytes")
        return [final]
    print(f"[split] {size:,} bytes > {max_bytes:,} → 분할")
    merged_tmp.unlink()
    return split_frames(frames, outdir, max_bytes)


# ---------- verify ----------
def verify_dir(outdir: Path) -> bool:
    files = sorted(outdir.glob('*.docx'))
    if not files:
        print("[verify] 산출물 없음"); return False
    ok = True
    total_paras = 0
    for f in files:
        d = Document(str(f))
        texts = [p.text for p in d.paragraphs]
        total_paras += len(texts)
        stars = sum(1 for t in texts if '**' in t)
        reps = sum(1 for t in texts if t.strip().startswith('〔') and '검수 리포트' in t)
        print(f"  {f.name}: 문단 {len(texts):,}  **잔존 {stars}  리포트헤더 {reps}")
        if stars:
            print(f"  [실패] {f.name}에 ** 마크다운 잔존 {stars}개"); ok = False
        if reps == 0:
            print(f"  [실패] {f.name}에 년도 리포트 헤더 없음"); ok = False
    print(f"[verify] {'통과' if ok else '실패'}  (총 문단 {total_paras:,})")
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd', choices=['build', 'split', 'verify'])
    ap.add_argument('--frame-dir', default='frames')
    ap.add_argument('--report', default='report.txt')
    ap.add_argument('--outdir', default='out')
    ap.add_argument('--merged')
    ap.add_argument('--max-bytes', type=int, default=14 * 1024 * 1024)
    a = ap.parse_args()
    if a.cmd == 'build':
        build(Path(a.frame_dir), Path(a.report), Path(a.outdir), a.max_bytes)
    elif a.cmd == 'verify':
        sys.exit(0 if verify_dir(Path(a.outdir)) else 1)
    else:
        frames = sorted(Path(a.frame_dir).glob('*.docx'), key=lambda p: p.name)
        split_frames(frames, Path(a.outdir), a.max_bytes)


if __name__ == '__main__':
    main()
